import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { User, UserRole, Product } from '../models/models';

@Injectable({ providedIn: 'root' })
export class UserService {
  private currentUser = new BehaviorSubject<User | null>(this.loadUserFromStorage());
  private users = new BehaviorSubject<User[]>(this.loadUsersFromStorage() || [
    { id: 1, name: 'Alice', email: 'alice@example.com', role: 'seller' },
    { id: 2, name: 'Bob', email: 'bob@example.com', role: 'buyer' },
    { id: 3, name: 'Charlie', email: 'charlie@example.com', role: 'seller' }
  ]);
  private products = new BehaviorSubject<Product[]>((() => {
    const stored = this.loadProductsFromStorage();
    
    // Define the new default products - one per category for clear filtering
    const defaultProducts = [
      { id: 1, name: 'Dell XPS 15 Laptop', description: 'Intel i7, 16GB RAM, 512GB SSD, Full HD Display', price: 125000, quantity: 5, sellerId: 1, category: 'Laptops' },
      { id: 2, name: 'iPhone 15 Pro', description: '256GB, Titanium Blue, A17 Pro Chip', price: 134900, quantity: 8, sellerId: 3, category: 'Mobiles' },
      { id: 3, name: 'Samsung Galaxy Tab S9', description: '11-inch, 128GB, WiFi + 5G', price: 62999, quantity: 12, sellerId: 1, category: 'Tablets' },
      { id: 4, name: 'Sony WH-1000XM5 Headphones', description: 'Wireless Noise-Canceling Headphones, 30hr Battery', price: 29990, quantity: 15, sellerId: 3, category: 'Audio' },
      { id: 5, name: 'Apple Watch Series 9', description: 'GPS + Cellular, 45mm, Midnight Aluminum', price: 49900, quantity: 10, sellerId: 1, category: 'Wearables' },
      { id: 6, name: 'Canon EOS R6 Camera', description: 'Mirrorless, 20MP, 4K Video, Body Only', price: 215000, quantity: 3, sellerId: 3, category: 'Cameras' },
      { id: 7, name: 'LG 55" OLED TV', description: '4K Ultra HD, Smart TV, Dolby Vision, webOS', price: 119990, quantity: 6, sellerId: 1, category: 'Home Entertainment' },
      { id: 8, name: 'Gaming Mouse Logitech G502', description: 'Hero 25K Sensor, RGB, 11 Programmable Buttons', price: 4999, quantity: 25, sellerId: 3, category: 'Accessories' }
    ];
    
    // Check if we have old products (less than 8 or old product names)
    const needsUpdate = !stored || stored.length < 8 || 
                        (stored.length > 0 && (stored[0].name === 'Laptop' || stored[0].name === 'Dell XPS 15 Laptop' && stored.length !== 8));
    
    if (needsUpdate) {
      // Update to new products
      localStorage.setItem('products', JSON.stringify(defaultProducts));
      console.log('Products updated to new catalog');
      return defaultProducts;
    }
    
    return stored;
  })());
  private nextUserId = this.users.value.reduce((max, user) => Math.max(max, user.id), 0) + 1;
  private nextProductId = this.products.value.reduce((max, product) => Math.max(max, product.id), 0) + 1;

  // Track sales: productId -> sold count
  private productSales = new Map<number, number>();

  currentUser$ = this.currentUser.asObservable();
  users$ = this.users.asObservable();
  products$ = this.products.asObservable();

  constructor() {
    // Service initialized
  }

  private loadUserFromStorage(): User | null {
    const userJson = localStorage.getItem('currentUser');
    return userJson ? JSON.parse(userJson) : null;
  }

  private loadUsersFromStorage(): User[] | null {
    const usersJson = localStorage.getItem('users');
    return usersJson ? JSON.parse(usersJson) : null;
  }

  private loadProductsFromStorage(): Product[] | null {
    const productsJson = localStorage.getItem('products');
    return productsJson ? JSON.parse(productsJson) : null;
  }

  private saveToStorage() {
    localStorage.setItem('currentUser', JSON.stringify(this.currentUser.value));
    localStorage.setItem('users', JSON.stringify(this.users.value));
    localStorage.setItem('products', JSON.stringify(this.products.value));
    
    // Save seller-specific products for quick access
    this.saveSellerProducts();
  }

  private saveSellerProducts() {
    // Group products by seller ID for individual seller tracking
    const sellerProductsMap: { [sellerId: number]: Product[] } = {};
    
    this.products.value.forEach(product => {
      if (!sellerProductsMap[product.sellerId]) {
        sellerProductsMap[product.sellerId] = [];
      }
      sellerProductsMap[product.sellerId].push(product);
    });
    
    // Save each seller's products separately
    Object.keys(sellerProductsMap).forEach(sellerId => {
      localStorage.setItem(
        `seller_${sellerId}_products`, 
        JSON.stringify(sellerProductsMap[Number(sellerId)])
      );
    });
  }

  // Get seller's products from their dedicated storage
  getSellerProductsFromStorage(sellerId: number): Product[] {
    const stored = localStorage.getItem(`seller_${sellerId}_products`);
    return stored ? JSON.parse(stored) : [];
  }

  // Cache for repeated user check
  private userCache = new Map<string, User>();

  loginUser(email: string): User | null {
    const user = this.users.value.find(u => u.email === email) || null;
    if (user) {
      this.currentUser.next(user);
      this.saveToStorage();
    }
    return user;
  }

  logoutUser() {
    this.currentUser.next(null);
    this.saveToStorage();
  }

  getCurrentUser(): User | null {
    return this.currentUser.value;
  }

  addUser(name: string, email: string, role: UserRole): { user: User, isRepeated: boolean } {
    const existing = this.users.value.find(u => u.email === email);
    if (existing) {
      return { user: existing, isRepeated: true };
    }
    const user: User = { id: this.nextUserId++, name, email, role };
    this.users.next([...this.users.value, user]);
    this.userCache.set(email, user);
    this.saveToStorage();
    return { user, isRepeated: false };
  }

  deleteUser(id: number) {
    if (this.currentUser.value?.id === id) {
      this.logoutUser();
    }
    this.users.next(this.users.value.filter(u => u.id !== id));
    this.products.next(this.products.value.filter(p => p.sellerId !== id));
    this.saveToStorage();
  }

  addProduct(product: Omit<Product, 'id'>) {
    const newProduct: Product = { ...product, id: this.nextProductId++ };
    console.log('✅ UserService: Adding product:', newProduct);
    
    this.products.next([...this.products.value, newProduct]);
    this.productSales.set(newProduct.id, 0);
    this.saveToStorage();
    
    console.log('✅ Product saved to localStorage');
    console.log('📦 Total products now:', this.products.value.length);
    console.log('🏪 Seller products:', this.products.value.filter(p => p.sellerId === product.sellerId).length);
    
    return newProduct;
  }

  purchaseProduct(productId: number, quantity: number): { success: boolean; error?: string } {
    const currentUser = this.getCurrentUser();
    if (!currentUser) {
      return { success: false, error: 'User not logged in' };
    }

    if (currentUser.role !== 'buyer') {
      return { success: false, error: 'Only buyers can purchase products' };
    }

    const product = this.products.value.find(p => p.id === productId);
    if (!product) {
      return { success: false, error: 'Product not found' };
    }

    if (product.quantity < quantity) {
      return { success: false, error: 'Insufficient stock available' };
    }

    // Update product quantity
    const updatedProducts = this.products.value.map(p => {
      if (p.id === productId) {
        return { ...p, quantity: p.quantity - quantity };
      }
      return p;
    });

    // Update sales tracking
    this.productSales.set(productId, (this.productSales.get(productId) || 0) + quantity);
    this.products.next(updatedProducts);
    this.saveToStorage();

    return { success: true };
  }

  getProductSales(productId: number): number {
    return this.productSales.get(productId) || 0;
  }

  buyProduct(productId: number, quantity: number): boolean {
    const products = this.products.value.map(p => {
      if (p.id === productId && p.quantity >= quantity) {
        return { ...p, quantity: p.quantity - quantity };
      }
      return p;
    });
    const found = this.products.value.find(p => p.id === productId && p.quantity >= quantity);
    if (found) {
      this.products.next(products);
      // Track sales
      const sold = this.productSales.get(productId) || 0;
      this.productSales.set(productId, sold + quantity);
      this.saveToStorage();
      return true;
    }
    return false;
  }

  // For seller dashboard: get stats for their products
  getSellerProductStats(sellerId: number) {
    const sellerProducts = this.products.value.filter(p => p.sellerId === sellerId);
    
    return sellerProducts.map(p => ({
      ...p,
      sold: this.productSales.get(p.id) || 0,
      remaining: p.quantity
    }));
  }

  // For repeated user popup
  isRepeatedUser(email: string): boolean {
    return !!this.users.value.find(u => u.email === email);
  }

  // Get seller's product summary from localStorage
  getSellerStorageSummary(sellerId: number): { totalProducts: number; totalValue: number; categories: string[] } {
    const sellerProducts = this.products.value.filter(p => p.sellerId === sellerId);
    const categories = [...new Set(sellerProducts.map(p => p.category))];
    const totalValue = sellerProducts.reduce((sum, p) => sum + (p.price * p.quantity), 0);
    
    return {
      totalProducts: sellerProducts.length,
      totalValue,
      categories
    };
  }

  // Reset products to default (useful for clearing old data)
  resetProducts() {
    const defaultProducts = [
      { id: 1, name: 'Dell XPS 15 Laptop', description: 'Intel i7, 16GB RAM, 512GB SSD, Full HD Display', price: 125000, quantity: 5, sellerId: 1, category: 'Laptops' },
      { id: 2, name: 'iPhone 15 Pro', description: '256GB, Titanium Blue, A17 Pro Chip', price: 134900, quantity: 8, sellerId: 3, category: 'Mobiles' },
      { id: 3, name: 'Samsung Galaxy Tab S9', description: '11-inch, 128GB, WiFi + 5G', price: 62999, quantity: 12, sellerId: 1, category: 'Tablets' },
      { id: 4, name: 'Sony WH-1000XM5 Headphones', description: 'Wireless Noise-Canceling Headphones, 30hr Battery', price: 29990, quantity: 15, sellerId: 3, category: 'Audio' },
      { id: 5, name: 'Apple Watch Series 9', description: 'GPS + Cellular, 45mm, Midnight Aluminum', price: 49900, quantity: 10, sellerId: 1, category: 'Wearables' },
      { id: 6, name: 'Canon EOS R6 Camera', description: 'Mirrorless, 20MP, 4K Video, Body Only', price: 215000, quantity: 3, sellerId: 3, category: 'Cameras' },
      { id: 7, name: 'LG 55" OLED TV', description: '4K Ultra HD, Smart TV, Dolby Vision, webOS', price: 119990, quantity: 6, sellerId: 1, category: 'Home Entertainment' },
      { id: 8, name: 'Gaming Mouse Logitech G502', description: 'Hero 25K Sensor, RGB, 11 Programmable Buttons', price: 4999, quantity: 25, sellerId: 3, category: 'Accessories' }
    ];
    
    localStorage.setItem('products', JSON.stringify(defaultProducts));
    this.products.next(defaultProducts);
    this.nextProductId = 9;
    console.log('Products reset to default:', defaultProducts);
  }
}
