// src/app/services/inventory.service.ts
 
import { Injectable } from '@angular/core';
 
import { HttpClient, HttpHeaders } from '@angular/common/http';
 
import { Observable } from 'rxjs';
 
 
 
export interface Inventory {
 
  inventoryID: number;
 
  itemName: string;
 
  stockQty: number;
 
  reorderQty: number;
 
  priorityStatus: number;
 
  createdDate?: string;
 
  lastUpdated?: string;
 
}
 
 
 
@Injectable({ providedIn: 'root' })
 
export class InventoryService {
 
  private baseUrl = 'http://localhost:5278/api';
 
 
 
  private httpOptions = {
 
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
 
  };
 
 
 
  constructor(private http: HttpClient) {}
 
 
 
  // Test connection
 
  testConnection(): Observable<any> {
 
    return this.http.get(`${this.baseUrl}/inventory`);
 
  }
 
 
 
  // Get all inventories
 
  getAllInventories(): Observable<Inventory[]> {
 
    return this.http.get<Inventory[]>(`${this.baseUrl}/inventory`);
 
  }
 
 
 
  // Add new inventory
 
  addInventory(item: Omit<Inventory, 'inventoryID'>): Observable<Inventory> {
 
    return this.http.post<Inventory>(`${this.baseUrl}/inventory`, item, this.httpOptions);
 
  }
 
 
 
  // Update inventory
 
  updateInventory(id: number, item: Inventory): Observable<void> {
 
    return this.http.put<void>(`${this.baseUrl}/inventory/${id}`, item, this.httpOptions);
 
  }
 
 
 
  // Delete inventory
 
  deleteInventory(id: number): Observable<void> {
 
    return this.http.delete<void>(`${this.baseUrl}/inventory/${id}`);
 
  }
 
}