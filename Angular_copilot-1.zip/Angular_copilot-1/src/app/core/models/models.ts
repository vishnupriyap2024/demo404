// =======================
// ✅ USER & ROLES
// =======================
export type UserRole = 'buyer' | 'seller' | 'admin' | 'supplier';

export interface User {
  id: number;              // unified field name (instead of both id and userID)
  name: string;           // replaces `name` for consistency
  email: string;
  role: UserRole;             // unified role system
  createdDate?: Date;
  isActive?: boolean;
}

// =======================
// ✅ PRODUCT (Linked to Inventory)
// =======================
export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  quantity: number;
  sellerId: number;          // links to User.userID with role = 'seller' or 'supplier'
  category: string;
  imageUrl?: string;
  inventoryID?: number;      // optional link to Inventory item
}

// =======================
// ✅ INVENTORY
// =======================
export interface Inventory {
  inventoryID: number;
  itemName: string;
  stockQty: number;
  reorderQty: number;
  priorityStatus: number;   // 0 = low, 1 = medium, 2 = high (for example)
  createdDate?: Date;
  lastUpdated?: Date;
}

// =======================
// ✅ STOCK TRANSACTIONS
// =======================
export interface Stock {
  stockID: number;
  inventoryID: number;
  quantity: number;
  transactionType: 'IN' | 'OUT' | 'ADJUSTMENT';  // restricted union type
  remarks?: string;
  userID: number;        // who performed the transaction
  transactionDate?: Date;
}

// =======================
// ✅ STOCK UPDATE REQUEST (e.g. API payload)
// =======================
export interface StockUpdateRequest {
  inventoryID: number;
  quantity: number;
  transactionType: 'IN' | 'OUT' | 'ADJUSTMENT';
  remarks: string;
  userID: number;
}