// src/app/models/inventory.models.ts
 
export interface Inventory {
  inventoryID: number;
  itemName: string;
  stockQty: number;
  reorderQty: number;
  priorityStatus: number;
  createdDate?: Date;
  lastUpdated?: Date;
}
 
export interface User {
  userID: number;
  userName: string;
  email: string;
  userType: string; // 'Admin', 'User', 'Supplier'
  createdDate?: Date;
  isActive?: boolean;
}
 
export interface Stock {
  stockID: number;
  inventoryID: number;
  quantity: number;
  transactionType: string; // 'IN', 'OUT', 'ADJUSTMENT'
  remarks?: string;
  userID: number;
  transactionDate?: Date;
}
 
export interface StockUpdateRequest {
  inventoryID: number;
  quantity: number;
  transactionType: string;
  remarks: string;
  userID: number;
}