import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
 
@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container">
      <h2>Inventory Dashboard</h2>
      <button (click)="testApi()" class="btn btn-primary">Test API</button>
      
      <div *ngIf="loading" class="loading">Loading...</div>
      <div *ngIf="error" class="alert alert-danger">{{ error }}</div>
      <div *ngIf="message" class="alert alert-success">{{ message }}</div>
      
      <div *ngIf="inventories.length > 0" class="inventory-list">
        <h3>Inventory Items:</h3>
        <ul>
          <li *ngFor="let item of inventories">
            <strong>{{ item.itemName }}</strong> — Stock: {{ item.stockQty }}
          </li>
        </ul>
      </div>
    </div>
  `,
  styles: [`
    .btn { background: #3b82f6; color: white; padding: 0.6rem 1.2rem; border: none; border-radius: 8px; cursor: pointer; }
    .alert-danger { background: #fee2e2; color: #b91c1c; padding: 1rem; margin: 1rem 0; }
    .alert-success { background: #d1fae5; color: #065f46; padding: 1rem; margin: 1rem 0; }
  `]
})
export class DashboardComponent implements OnInit {
  inventories: any[] = [];
  loading = false;
  error = '';
  message = '';
 
  constructor(private http: HttpClient) {
    console.log('🏗️ Dashboard Component Constructor Called');
  }
 
  ngOnInit(): void {
    console.log('🚀 Dashboard Component NgOnInit Called');
    // Don't auto-call testApi here, let user click button
  }
 
  testApi() {
    console.log('🔘 Test API Button Clicked!'); // This should appear when you click
    
    this.loading = true;
    this.error = '';
    this.message = '';
    
    console.log('📡 Making HTTP Request to: http://localhost:5278/api/inventory');
    
    this.http.get<any[]>('http://localhost:5278/api/inventory').subscribe({
      next: (data) => {
        console.log('✅ API SUCCESS! Received data:', data);
        this.inventories = data || [];
        this.message = `Successfully loaded ${data?.length || 0} items from API`;
        this.loading = false;
      },
      error: (err) => {
        console.error('❌ API ERROR:', err);
        this.error = `API Error: ${err.status} - ${err.message}`;
        this.loading = false;
      }
    });
  }
}